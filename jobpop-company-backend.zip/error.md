
Client disconnected
Client connected
Client disconnected
GET /api/auth/profile 304 415.186 ms - -
GET /api/jobs/categories 304 412.391 ms - -
GET /api/jobs?page=1&limit=5 304 722.145 ms - -
GET /api/subscription/status 304 759.885 ms - -
GET /api/subscription/status 304 641.999 ms - -
GET /api/jobs/stats 304 1638.435 ms - -
POST /api/auth/login 200 678.714 ms - 676
GET /api/jobs/categories 304 384.455 ms - -
GET /api/subscription/status 304 702.226 ms - -
GET /api/jobs?page=1&limit=5 304 737.549 ms - -
GET /api/jobs/stats 304 1327.962 ms - -
GET /api/subscription/status 304 711.257 ms - -
Selected plan type: per_job
Resolved plan details: { amount: 10000, description: 'Per Job Post' }
POST /api/subscription/initiate 200 3514.577 ms - 2
Selected plan type: monthly
Resolved plan details: { amount: 50000, description: 'Monthly Subscription' }
POST /api/subscription/initiate 200 3496.633 ms - 2
